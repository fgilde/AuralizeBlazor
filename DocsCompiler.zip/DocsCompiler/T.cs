﻿namespace MudBlazor.UnitTests
{
    public class T { }
    public class U { }
}
